中文环境下可用的scihub论文下载器

感谢作者[@zaytoun/scihub.py](https://github.com/zaytoun/scihub.py)

# 更新日志

2020-05-28 补充：基于@zaytoun的源码更新scihub提取网，目前项目可用，感谢@lisenjor的分享。

2020-06-25 补充：增加关键词搜索批量下载论文功能。


# 使用教程

见[你不得不知道的python超级文献下载搜索工具](https://pythondict.com/life-intelligent/tools/python-paper-downloader/)

# 更多

更多有趣的工具和组件的使用，可以关注Python实用宝典网站或公众号, 会定时更新[Python实战教程](https://pythondict.com)