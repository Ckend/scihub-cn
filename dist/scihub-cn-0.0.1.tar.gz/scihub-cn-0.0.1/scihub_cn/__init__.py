from scihub import main

__all__ = ['main']
